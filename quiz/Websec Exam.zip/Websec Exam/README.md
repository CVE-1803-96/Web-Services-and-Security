# Web Security Exam Application

A comprehensive web application for conducting web security exams with multiple question types including single/multiple choice, drag-and-drop, matching, fill-in-the-blank, and simulation scenarios.

## Features

- **User Registration**: Users register with their full name
- **Session Management**: Each user gets a unique session
- **40 Questions**: Mix of different question types and difficulty levels
- **Multiple Question Types**:
  - Single choice questions
  - Multiple choice questions
  - Drag and drop ordering
  - Matching pairs
  - Fill in the gap
  - Simulation scenarios (vulnerability testing)

- **Topics Covered**:
  - IDOR (Insecure Direct Object Reference)
  - XSS (Cross-Site Scripting)
  - SQL Injection
  - NoSQL Injection
  - CSRF (Cross-Site Request Forgery)
  - Authentication Bypass
  - Security Fundamentals (CIA triad, Authentication, Authorization, Non-repudiation)

- **Scoring System**: 0.25 points per question, total of 10 points
- **Detailed Results**: 
  - Total score and percentage
  - Performance breakdown by topic
  - Question-by-question review with correct/incorrect answers
  - User's answers displayed alongside correct answers

- **Simulation Endpoints**: Test vulnerabilities in real-time:
  - XSS testing endpoint
  - IDOR testing endpoint
  - CSRF testing endpoint

## Installation

1. Install Node.js (v14 or higher)

2. Install dependencies:
```bash
npm install
```

## Running the Application

1. Start the server:
```bash
npm start
```

2. Open your browser and navigate to:
```
http://localhost:3000
```

## Usage

1. **Registration**: Enter your full name on the registration page
2. **Take Exam**: Answer 40 questions across different types
3. **Simulation Questions**: For simulation questions, click the link to test vulnerabilities in a new tab
4. **Submit**: Review your answers and submit when ready
5. **View Results**: See your score, topic breakdown, and detailed corrections

## Data Storage

All data is stored in JSON files in the `data/` directory:
- `users.json` - User registrations
- `sessions.json` - Active exam sessions
- `questions.json` - Exam questions
- `exam_results.json` - Completed exam results

## Project Structure

```
.
├── server.js              # Express server and API endpoints
├── package.json           # Dependencies
├── data/                  # JSON database files
│   ├── users.json
│   ├── sessions.json
│   ├── questions.json
│   └── exam_results.json
└── public/                # Frontend files
    ├── index.html         # Registration page
    ├── exam.html          # Exam interface
    ├── results.html       # Results page
    ├── styles.css         # Styling
    ├── app.js             # Registration logic
    ├── exam.js            # Exam logic
    └── results.js         # Results display
```

## API Endpoints

- `POST /api/register` - Register a new user
- `GET /api/session` - Get current session info
- `POST /api/start-exam` - Start the exam
- `GET /api/questions` - Get all questions
- `POST /api/save-answer` - Save an answer
- `POST /api/submit-exam` - Submit the exam
- `GET /api/results` - Get exam results
- `GET /api/simulation/xss-test` - XSS vulnerability test
- `GET /api/simulation/idor-test` - IDOR vulnerability test
- `POST /api/simulation/csrf-test` - CSRF vulnerability test

## Question Difficulties

- **Easy**: Basic concepts and definitions
- **Medium**: Practical application of concepts
- **Hard**: Advanced exploitation techniques and scenarios

## Notes

- Each question is worth 0.25 points
- Total exam score is 10 points (40 questions × 0.25)
- Answers are saved automatically as you progress
- You can navigate between questions using Previous/Next buttons or question numbers
- Simulation questions require you to test endpoints in separate tabs/windows

