const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const cors = require('cors');
const fs = require('fs').promises;
const path = require('path');
const { v4: uuidv4 } = require('uuid');

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));
app.use(session({
  secret: 'websec-exam-secret-key-2024',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false, maxAge: 24 * 60 * 60 * 1000 } // 24 hours
}));

// Data storage paths
const DATA_DIR = path.join(__dirname, 'data');
const USERS_FILE = path.join(DATA_DIR, 'users.json');
const SESSIONS_FILE = path.join(DATA_DIR, 'sessions.json');
const QUESTIONS_FILE = path.join(DATA_DIR, 'questions.json');
const EXAM_RESULTS_FILE = path.join(DATA_DIR, 'exam_results.json');

// Ensure data directory exists
async function ensureDataDir() {
  try {
    await fs.mkdir(DATA_DIR, { recursive: true });
    // Initialize files if they don't exist
    try {
      await fs.access(USERS_FILE);
    } catch {
      await fs.writeFile(USERS_FILE, JSON.stringify([]));
    }
    try {
      await fs.access(SESSIONS_FILE);
    } catch {
      await fs.writeFile(SESSIONS_FILE, JSON.stringify([]));
    }
    try {
      await fs.access(EXAM_RESULTS_FILE);
    } catch {
      await fs.writeFile(EXAM_RESULTS_FILE, JSON.stringify([]));
    }
  } catch (error) {
    console.error('Error ensuring data directory:', error);
  }
}

// Helper functions to read/write JSON
async function readJSON(file) {
  try {
    const data = await fs.readFile(file, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    return [];
  }
}

async function writeJSON(file, data) {
  await fs.writeFile(file, JSON.stringify(data, null, 2));
}

// API Routes

// Register user
app.post('/api/register', async (req, res) => {
  try {
    const { fullName } = req.body;
    if (!fullName || fullName.trim().length < 3) {
      return res.status(400).json({ error: 'Full name must be at least 3 characters' });
    }

    const users = await readJSON(USERS_FILE);
    const userId = uuidv4();
    const newUser = {
      id: userId,
      fullName: fullName.trim(),
      registeredAt: new Date().toISOString()
    };

    users.push(newUser);
    await writeJSON(USERS_FILE, users);

    // Create session
    const sessions = await readJSON(SESSIONS_FILE);
    const sessionId = uuidv4();
    const newSession = {
      sessionId,
      userId,
      createdAt: new Date().toISOString(),
      examStarted: false,
      examCompleted: false,
      answers: {}
    };
    sessions.push(newSession);
    await writeJSON(SESSIONS_FILE, sessions);

    req.session.userId = userId;
    req.session.sessionId = sessionId;

    res.json({ success: true, userId, sessionId, fullName: newUser.fullName });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get session info
app.get('/api/session', async (req, res) => {
  try {
    if (!req.session.userId) {
      return res.status(401).json({ error: 'Not authenticated' });
    }

    const sessions = await readJSON(SESSIONS_FILE);
    const sessionData = sessions.find(s => s.sessionId === req.session.sessionId);
    const users = await readJSON(USERS_FILE);
    const user = users.find(u => u.id === req.session.userId);

    if (!sessionData || !user) {
      return res.status(404).json({ error: 'Session or user not found' });
    }

    res.json({
      userId: user.id,
      fullName: user.fullName,
      sessionId: sessionData.sessionId,
      examStarted: sessionData.examStarted,
      examCompleted: sessionData.examCompleted,
      answers: sessionData.answers || {}
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Start exam
app.post('/api/start-exam', async (req, res) => {
  try {
    if (!req.session.userId) {
      return res.status(401).json({ error: 'Not authenticated' });
    }

    const sessions = await readJSON(SESSIONS_FILE);
    const sessionIndex = sessions.findIndex(s => s.sessionId === req.session.sessionId);
    
    if (sessionIndex === -1) {
      return res.status(404).json({ error: 'Session not found' });
    }

    sessions[sessionIndex].examStarted = true;
    sessions[sessionIndex].startedAt = new Date().toISOString();
    await writeJSON(SESSIONS_FILE, sessions);

    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get questions
app.get('/api/questions', async (req, res) => {
  try {
    if (!req.session.userId) {
      return res.status(401).json({ error: 'Not authenticated' });
    }

    const questions = await readJSON(QUESTIONS_FILE);
    // Remove correct answers before sending
    const questionsForExam = questions.map(q => {
      const { correctAnswer, ...questionWithoutAnswer } = q;
      return questionWithoutAnswer;
    });

    res.json(questionsForExam);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Save answer
app.post('/api/save-answer', async (req, res) => {
  try {
    if (!req.session.userId) {
      return res.status(401).json({ error: 'Not authenticated' });
    }

    const { questionId, answer } = req.body;

    const sessions = await readJSON(SESSIONS_FILE);
    const sessionIndex = sessions.findIndex(s => s.sessionId === req.session.sessionId);
    
    if (sessionIndex === -1) {
      return res.status(404).json({ error: 'Session not found' });
    }

    sessions[sessionIndex].answers[questionId] = answer;
    await writeJSON(SESSIONS_FILE, sessions);

    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Submit exam
app.post('/api/submit-exam', async (req, res) => {
  try {
    if (!req.session.userId) {
      return res.status(401).json({ error: 'Not authenticated' });
    }

    const sessions = await readJSON(SESSIONS_FILE);
    const sessionIndex = sessions.findIndex(s => s.sessionId === req.session.sessionId);
    
    if (sessionIndex === -1) {
      return res.status(404).json({ error: 'Session not found' });
    }

    const sessionData = sessions[sessionIndex];
    sessionData.examCompleted = true;
    sessionData.submittedAt = new Date().toISOString();

    // Grade the exam
    const questions = await readJSON(QUESTIONS_FILE);
    const results = calculateResults(questions, sessionData.answers);

    // Save results
    const examResults = await readJSON(EXAM_RESULTS_FILE);
    const resultRecord = {
      resultId: uuidv4(),
      userId: req.session.userId,
      sessionId: sessionData.sessionId,
      submittedAt: sessionData.submittedAt,
      ...results
    };
    examResults.push(resultRecord);
    await writeJSON(EXAM_RESULTS_FILE, examResults);

    await writeJSON(SESSIONS_FILE, sessions);

    res.json(results);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get results
app.get('/api/results', async (req, res) => {
  try {
    if (!req.session.userId) {
      return res.status(401).json({ error: 'Not authenticated' });
    }

    const examResults = await readJSON(EXAM_RESULTS_FILE);
    const sessionData = await readJSON(SESSIONS_FILE);
    const session = sessionData.find(s => s.sessionId === req.session.sessionId);
    
    const result = examResults.find(r => r.sessionId === req.session.sessionId);
    const questions = await readJSON(QUESTIONS_FILE);

    if (!result) {
      return res.status(404).json({ error: 'Results not found' });
    }

    // Include questions with correct answers for display
    res.json({
      ...result,
      questions: questions,
      userAnswers: session.answers
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Calculate results
function calculateResults(questions, userAnswers) {
  let totalScore = 0;
  const questionResults = [];
  const topicScores = {};
  const topicCounts = {};

  questions.forEach(question => {
    const userAnswer = userAnswers[question.id] || null;
    const isCorrect = checkAnswer(question, userAnswer);
    const score = isCorrect ? 0.25 : 0;

    totalScore += score;

    // Track topic scores
    if (!topicScores[question.topic]) {
      topicScores[question.topic] = 0;
      topicCounts[question.topic] = 0;
    }
    topicCounts[question.topic]++;
    if (isCorrect) {
      topicScores[question.topic] += score;
    }

    questionResults.push({
      questionId: question.id,
      isCorrect,
      userAnswer,
      correctAnswer: question.correctAnswer,
      score
    });
  });

  // Calculate topic percentages
  const topicPercentages = {};
  Object.keys(topicScores).forEach(topic => {
    const totalForTopic = topicCounts[topic] * 0.25;
    const scoreForTopic = topicScores[topic];
    topicPercentages[topic] = totalForTopic > 0 
      ? ((scoreForTopic / totalForTopic) * 100).toFixed(2) 
      : 0;
  });

  return {
    totalScore: parseFloat(totalScore.toFixed(2)),
    maxScore: 10.0,
    percentage: parseFloat(((totalScore / 10) * 100).toFixed(2)),
    questionResults,
    topicPercentages,
    topicScores,
    topicCounts
  };
}

// Check if answer is correct based on question type
function checkAnswer(question, userAnswer) {
  if (!userAnswer) return false;

  switch (question.type) {
    case 'single':
      return userAnswer === question.correctAnswer;
    
    case 'multiple':
      if (!Array.isArray(userAnswer)) return false;
      const correct = question.correctAnswer.sort();
      const user = [...userAnswer].sort();
      return JSON.stringify(correct) === JSON.stringify(user);
    
    case 'drag-drop':
    case 'match':
      if (!Array.isArray(userAnswer) || !Array.isArray(question.correctAnswer)) return false;
      // Normalize match answers - compare pairs regardless of order
      const normalizeMatches = (matches) => {
        return matches.map(m => {
          if (typeof m === 'object' && m.left && m.right) {
            return `${m.left}|${m.right}`;
          }
          return String(m);
        }).sort().join('||');
      };
      return normalizeMatches(userAnswer) === normalizeMatches(question.correctAnswer);
    
    case 'fill-gap':
      if (!Array.isArray(userAnswer)) return false;
      return JSON.stringify(userAnswer) === JSON.stringify(question.correctAnswer);
    
    case 'simulation':
      // For simulations, check if the user's answer matches the expected exploit
      return userAnswer === question.correctAnswer;
    
    default:
      return false;
  }
}

// Simulation endpoints for vulnerability testing (generic names to avoid revealing vulnerability type)
app.get('/api/simulation/endpoint-a1b2c3', (req, res) => {
  const userId = req.query.userId;
  
  // Simulate different users' data - IDOR vulnerability
  const usersData = {
    '1': { userId: 1, name: 'Admin User', email: 'admin@example.com', role: 'admin', salary: 100000 },
    '2': { userId: 2, name: 'John Doe', email: 'john@example.com', role: 'user', salary: 50000 },
    '3': { userId: 3, name: 'Jane Smith', email: 'jane@example.com', role: 'user', salary: 55000 },
    '4': { userId: 4, name: 'Bob Johnson', email: 'bob@example.com', role: 'manager', salary: 75000 }
  };
  
  // Vulnerable endpoint: no authorization check, just returns data based on userId parameter
  if (userId && usersData[userId]) {
    return res.json({ 
      message: 'User profile retrieved successfully',
      data: usersData[userId]
    });
  }
  
  res.status(404).json({ error: 'User not found' });
});

app.get('/api/simulation/endpoint-d4e5f6', (req, res) => {
  const input = req.query.input || '';
  // XSS vulnerability - reflects user input without sanitization
  res.send(`
    <html>
      <head><title>User Feedback</title></head>
      <body style="font-family: Arial; padding: 20px;">
        <h1>User Feedback Display</h1>
        <p><strong>Your feedback:</strong> ${input}</p>
        <p style="color: #666; margin-top: 30px;">Thank you for your input!</p>
      </body>
    </html>
  `);
});

app.post('/api/simulation/endpoint-g7h8i9', (req, res) => {
  // CSRF vulnerability - accepts state-changing requests without CSRF protection
  res.json({ 
    message: 'Profile updated successfully', 
    success: true,
    timestamp: new Date().toISOString()
  });
});

// Initialize data directory and start server
ensureDataDir().then(() => {
  app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
});

