// Results page JavaScript
document.addEventListener('DOMContentLoaded', async function() {
    await loadResults();
});

async function loadResults() {
    try {
        const response = await fetch('/api/results');
        if (!response.ok) {
            if (response.status === 404) {
                window.location.href = 'exam.html';
                return;
            }
            throw new Error('Failed to load results');
        }

        const data = await response.json();
        displayResults(data);
    } catch (error) {
        console.error('Load results error:', error);
        document.querySelector('.container').innerHTML = 
            '<div class="error-message">Failed to load results. Please try again.</div>';
    }
}

function displayResults(data) {
    // Display user name
    document.getElementById('userName').textContent = `Results for Session`;

    // Display score
    document.getElementById('scoreValue').textContent = data.totalScore.toFixed(2);
    document.getElementById('maxScore').textContent = data.maxScore;
    document.getElementById('scorePercentage').textContent = `${data.percentage}%`;

    // Display topic breakdown
    displayTopicBreakdown(data.topicPercentages);

    // Display question review
    displayQuestionReview(data.questions, data.userAnswers, data.questionResults);
}

function displayTopicBreakdown(topicPercentages) {
    const container = document.getElementById('topicChart');
    container.innerHTML = '';

    Object.entries(topicPercentages).forEach(([topic, percentage]) => {
        const topicItem = document.createElement('div');
        topicItem.className = 'topic-item';

        const header = document.createElement('div');
        header.className = 'topic-header';
        header.innerHTML = `
            <span><strong>${topic}</strong></span>
            <span>${percentage}%</span>
        `;

        const bar = document.createElement('div');
        bar.className = 'topic-bar';

        const fill = document.createElement('div');
        fill.className = 'topic-bar-fill';
        fill.style.width = `${percentage}%`;
        fill.textContent = `${percentage}%`;

        bar.appendChild(fill);
        topicItem.appendChild(header);
        topicItem.appendChild(bar);
        container.appendChild(topicItem);
    });
}

function displayQuestionReview(questions, userAnswers, questionResults) {
    const container = document.getElementById('answersContainer');
    container.innerHTML = '';

    questions.forEach((question, index) => {
        const result = questionResults.find(r => r.questionId === question.id);
        if (!result) return;

        const answerItem = document.createElement('div');
        answerItem.className = `answer-item ${result.isCorrect ? 'correct' : 'incorrect'}`;

        let userAnswerDisplay = formatAnswer(question, result.userAnswer);
        let correctAnswerDisplay = formatAnswer(question, result.correctAnswer);

        answerItem.innerHTML = `
            <div class="answer-question">
                <strong>Question ${index + 1}:</strong> ${question.question}
                <span class="topic-tag" style="margin-left: 10px;">${question.topic}</span>
                <span class="difficulty-tag difficulty-${question.difficulty}" style="margin-left: 5px;">${question.difficulty}</span>
            </div>
            <div class="answer-user">
                <strong>Your Answer:</strong> ${userAnswerDisplay || 'Not answered'}
            </div>
            <div class="answer-correct">
                <strong>Correct Answer:</strong> ${correctAnswerDisplay}
            </div>
            <div class="answer-status ${result.isCorrect ? 'correct-text' : 'incorrect-text'}">
                ${result.isCorrect ? '✓ Correct' : '✗ Incorrect'} (${result.score.toFixed(2)} / 0.25 points)
            </div>
        `;

        container.appendChild(answerItem);
    });
}

function formatAnswer(question, answer) {
    if (!answer) return 'Not answered';

    switch (question.type) {
        case 'single':
            return answer;
        
        case 'multiple':
            if (Array.isArray(answer)) {
                return answer.join(', ');
            }
            return answer;
        
        case 'fill-gap':
            if (Array.isArray(answer)) {
                return answer.join(', ');
            }
            return answer;
        
        case 'match':
            if (Array.isArray(answer)) {
                return answer.map(pair => `${pair.left} → ${pair.right}`).join('; ');
            }
            return JSON.stringify(answer);
        
        case 'drag-drop':
            if (Array.isArray(answer)) {
                return answer.map((item, index) => `${index + 1}. ${item}`).join(', ');
            }
            return JSON.stringify(answer);
        
        case 'simulation':
            return answer;
        
        default:
            return JSON.stringify(answer);
    }
}

