// Exam page JavaScript
let questions = [];
let currentQuestionIndex = 0;
let userAnswers = {};
let sessionData = null;

document.addEventListener('DOMContentLoaded', async function() {
    // Check session
    await checkSession();
    
    // Load questions (will initialize exam after loading)
    await loadQuestions();

    // Event listeners
    document.getElementById('prevBtn').addEventListener('click', () => navigateQuestion(-1));
    document.getElementById('nextBtn').addEventListener('click', () => navigateQuestion(1));
    document.getElementById('submitBtn').addEventListener('click', showSubmitModal);
    document.getElementById('cancelSubmit').addEventListener('click', hideSubmitModal);
    document.getElementById('confirmSubmit').addEventListener('click', submitExam);
});

async function checkSession() {
    try {
        const response = await fetch('/api/session');
        if (response.ok) {
            sessionData = await response.json();
            document.getElementById('userName').textContent = `Welcome, ${sessionData.fullName}`;
            
            if (!sessionData.examStarted) {
                await fetch('/api/start-exam', { method: 'POST' });
            }
        } else {
            window.location.href = 'index.html';
        }
    } catch (error) {
        console.error('Session check error:', error);
        window.location.href = 'index.html';
    }
}

async function loadQuestions() {
    try {
        const response = await fetch('/api/questions');
        if (response.ok) {
            questions = await response.json();
            document.getElementById('totalQuestions').textContent = questions.length;
            await loadSavedAnswers();
            if (questions.length > 0) {
                displayQuestion(0);
                setupNavigation();
                updateProgress();
                updateQuestionNumbers();
            }
        } else {
            document.getElementById('questionsContainer').innerHTML = 
                '<div class="error-message">Failed to load questions. Please refresh the page.</div>';
        }
    } catch (error) {
        console.error('Load questions error:', error);
        document.getElementById('questionsContainer').innerHTML = 
            '<div class="error-message">Network error. Please check your connection.</div>';
    }
}

async function loadSavedAnswers() {
    try {
        const response = await fetch('/api/session');
        if (response.ok) {
            const session = await response.json();
            if (session.answers) {
                userAnswers = { ...userAnswers, ...session.answers };
            }
        }
    } catch (error) {
        console.error('Load saved answers error:', error);
    }
}

function displayQuestion(index) {
    if (index < 0 || index >= questions.length) return;
    
    currentQuestionIndex = index;
    const question = questions[index];
    const container = document.getElementById('questionsContainer');
    
    // Hide all question cards
    document.querySelectorAll('.question-card').forEach(card => {
        card.classList.remove('active');
    });
    
    // Create question card if it doesn't exist
    let questionCard = document.getElementById(`question-${question.id}`);
    if (!questionCard) {
        questionCard = createQuestionCard(question);
        container.appendChild(questionCard);
    } else {
        // If card exists, reattach event listeners for match questions
        if (question.type === 'match') {
            attachMatchEventListeners(questionCard, question.id);
        }
    }
    
    questionCard.classList.add('active');
    
    // Update navigation
    updateNavigation();
    updateProgress();
    updateQuestionNumbers();
}

function createQuestionCard(question) {
    const card = document.createElement('div');
    card.className = 'question-card';
    card.id = `question-${question.id}`;
    
    const header = `
        <div class="question-header">
            <span class="difficulty-tag difficulty-${question.difficulty}">${question.difficulty}</span>
        </div>
        <div class="question-text">${question.question}</div>
    `;
    
    let body = '';
    
    switch (question.type) {
        case 'single':
            body = createSingleChoiceOptions(question);
            break;
        case 'multiple':
            body = createMultipleChoiceOptions(question);
            break;
        case 'fill-gap':
            body = createFillGapOptions(question);
            break;
        case 'match':
            body = createMatchOptions(question);
            break;
        case 'drag-drop':
            body = createDragDropOptions(question);
            break;
        case 'simulation':
            body = createSimulationOptions(question);
            break;
    }
    
    card.innerHTML = header + body;
    
    // Attach event listeners for match questions
    if (question.type === 'match') {
        attachMatchEventListeners(card, question.id);
    }
    
    return card;
}

function attachMatchEventListeners(card, questionId) {
    const matchItems = card.querySelectorAll('.match-item:not(.matched)');
    matchItems.forEach(item => {
        // Click-to-select functionality
        item.addEventListener('click', function() {
            const side = this.dataset.side;
            const index = parseInt(this.dataset.index);
            const value = this.textContent.trim().replace(/\s*\(Matched\)\s*$/, ''); // Get the text without the "(Matched)" label
            selectMatchItem(questionId, side, index, value);
        });
        
        // Drag-and-drop functionality for left items
        if (item.dataset.side === 'left' && !item.classList.contains('matched')) {
            item.addEventListener('dragstart', function(e) {
                e.dataTransfer.effectAllowed = 'move';
                const value = this.textContent.trim().replace(/\s*\(Matched\)\s*$/, '');
                e.dataTransfer.setData('text/plain', JSON.stringify({
                    side: this.dataset.side,
                    value: value,
                    questionId: questionId
                }));
                this.classList.add('dragging');
            });
            
            item.addEventListener('dragend', function(e) {
                this.classList.remove('dragging');
            });
        }
        
        // Drop zones for right items
        if (item.dataset.side === 'right' && !item.classList.contains('matched')) {
            item.addEventListener('dragover', function(e) {
                e.preventDefault();
                e.dataTransfer.dropEffect = 'move';
                this.classList.add('drag-over');
            });
            
            item.addEventListener('dragleave', function(e) {
                this.classList.remove('drag-over');
            });
            
            item.addEventListener('drop', function(e) {
                e.preventDefault();
                this.classList.remove('drag-over');
                
                try {
                    const dragData = JSON.parse(e.dataTransfer.getData('text/plain'));
                    const rightValue = this.textContent.trim().replace(/\s*\(Matched\)\s*$/, '');
                    if (dragData.questionId === questionId && dragData.side === 'left') {
                        const pairs = userAnswers[questionId] || [];
                        const newPair = {
                            left: dragData.value,
                            right: rightValue
                        };
                        
                        // Check if this pair already exists
                        const pairExists = pairs.some(p => 
                            p.left === newPair.left && p.right === newPair.right
                        );
                        
                        if (!pairExists) {
                            pairs.push(newPair);
                            userAnswers[questionId] = pairs;
                            saveAnswer(questionId, pairs);
                            displayQuestion(currentQuestionIndex);
                        }
                    }
                } catch (error) {
                    console.error('Drop error:', error);
                }
            });
        }
    });
    
    const removeButtons = card.querySelectorAll('.remove-match-btn');
    removeButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const pairIndex = parseInt(this.dataset.pairIndex);
            removeMatch(questionId, pairIndex);
        });
    });
}

function createSingleChoiceOptions(question) {
    let html = '<div class="options-container">';
    question.options.forEach((option, index) => {
        const isChecked = userAnswers[question.id] === option ? 'checked' : '';
        html += `
            <label class="option-item ${isChecked ? 'selected' : ''}">
                <input type="radio" name="question-${question.id}" value="${option}" ${isChecked} 
                       onchange="handleSingleChoice('${question.id}', '${option.replace(/'/g, "\\'")}')">
                ${option}
            </label>
        `;
    });
    html += '</div>';
    return html;
}

function createMultipleChoiceOptions(question) {
    let html = '<div class="options-container">';
    const selected = userAnswers[question.id] || [];
    question.options.forEach((option, index) => {
        const isChecked = selected.includes(option) ? 'checked' : '';
        html += `
            <label class="option-item ${isChecked ? 'selected' : ''}">
                <input type="checkbox" name="question-${question.id}" value="${option}" ${isChecked}
                       onchange="handleMultipleChoice('${question.id}', '${option.replace(/'/g, "\\'")}')">
                ${option}
            </label>
        `;
    });
    html += '</div>';
    return html;
}

function createFillGapOptions(question) {
    const answers = userAnswers[question.id] || question.options.map(() => '');
    let html = '<div class="fill-gap-container">';
    const parts = question.question.split('____');
    
    parts.forEach((part, index) => {
        html += part;
        if (index < parts.length - 1) {
            html += `<input type="text" class="fill-gap-input" 
                           data-question="${question.id}" 
                           data-index="${index}"
                           value="${answers[index] || ''}"
                           onchange="handleFillGap('${question.id}', ${index}, this.value)">`;
        }
    });
    html += '</div>';
    return html;
}

function createMatchOptions(question) {
    let html = '<div class="match-container">';
    const selected = userAnswers[question.id] || [];
    
    // Track which items are already matched
    const matchedLeft = new Set(selected.map(p => p.left));
    const matchedRight = new Set(selected.map(p => p.right));
    
    html += '<div class="match-column"><h4>Left Column (Drag from here)</h4>';
    question.leftItems.forEach((item, index) => {
        const isMatched = matchedLeft.has(item);
        html += `<div class="match-item ${isMatched ? 'matched' : ''}" 
                       draggable="${!isMatched}"
                       data-side="left" 
                       data-index="${index}"
                       data-question-id="${question.id}">
            ${item} ${isMatched ? '<span style="color: #28a745;">(Matched)</span>' : ''}
        </div>`;
    });
    html += '</div>';
    
    html += '<div class="match-column"><h4>Right Column (Drop here)</h4>';
    question.rightItems.forEach((item, index) => {
        const isMatched = matchedRight.has(item);
        html += `<div class="match-item ${isMatched ? 'matched' : ''}" 
                       data-side="right" 
                       data-index="${index}"
                       data-question-id="${question.id}">
            ${item} ${isMatched ? '<span style="color: #28a745;">(Matched)</span>' : ''}
        </div>`;
    });
    html += '</div>';
    html += '</div>';
    
    // Display matched pairs if any
    if (selected.length > 0) {
        html += '<div class="match-pairs"><h4>Your Matches:</h4>';
        selected.forEach((pair, index) => {
            html += `<div class="match-pair" data-pair-index="${index}">
                <span>${pair.left}</span> → <span>${pair.right}</span>
                <button class="remove-match-btn" data-question-id="${question.id}" data-pair-index="${index}" style="margin-left: 10px; padding: 5px 10px; background: #dc3545; color: white; border: none; border-radius: 5px; cursor: pointer;">Remove</button>
            </div>`;
        });
        html += '</div>';
    }
    
    return html;
}

let matchSelections = {};

function selectMatchItem(questionId, side, index, value) {
    if (!matchSelections[questionId]) {
        matchSelections[questionId] = { left: null, right: null };
    }
    
    // If clicking the same item, deselect it
    if (matchSelections[questionId][side] && matchSelections[questionId][side].index === index) {
        matchSelections[questionId][side] = null;
        document.querySelectorAll(`#question-${questionId} .match-item[data-side="${side}"]`).forEach(item => {
            item.classList.remove('selected');
        });
        return;
    }
    
    matchSelections[questionId][side] = { index, value };
    
    // Update UI - remove all selections first
    document.querySelectorAll(`#question-${questionId} .match-item`).forEach(item => {
        item.classList.remove('selected');
    });
    
    // Highlight selected items
    if (matchSelections[questionId].left) {
        const leftItem = document.querySelector(
            `#question-${questionId} .match-item[data-side="left"][data-index="${matchSelections[questionId].left.index}"]`
        );
        if (leftItem) {
            leftItem.classList.add('selected');
        }
    }
    
    if (matchSelections[questionId].right) {
        const rightItem = document.querySelector(
            `#question-${questionId} .match-item[data-side="right"][data-index="${matchSelections[questionId].right.index}"]`
        );
        if (rightItem) {
            rightItem.classList.add('selected');
        }
    }
    
    // If both sides selected, create a pair
    if (matchSelections[questionId].left && matchSelections[questionId].right) {
        const pairs = userAnswers[questionId] || [];
        const newPair = {
            left: matchSelections[questionId].left.value,
            right: matchSelections[questionId].right.value
        };
        
        // Check if this pair already exists
        const pairExists = pairs.some(p => 
            p.left === newPair.left && p.right === newPair.right
        );
        
        if (!pairExists) {
            pairs.push(newPair);
            userAnswers[questionId] = pairs;
            saveAnswer(questionId, pairs);
        }
        
        matchSelections[questionId] = { left: null, right: null };
        
        // Refresh the question display after a short delay to show the match
        setTimeout(() => {
            displayQuestion(currentQuestionIndex);
        }, 300);
    }
}

function removeMatch(questionId, index) {
    const pairs = userAnswers[questionId] || [];
    pairs.splice(index, 1);
    userAnswers[questionId] = pairs.length > 0 ? pairs : [];
    saveAnswer(questionId, userAnswers[questionId]);
    displayQuestion(currentQuestionIndex);
}

function createDragDropOptions(question) {
    const order = userAnswers[question.id] || [...question.items];
    let html = '<div class="drag-drop-container">';
    html += '<p>Drag and drop items to reorder them:</p>';
    html += '<div class="drag-list" id="drag-list-' + question.id + '" ondragover="handleDragOver(event)" ondrop="handleDrop(event, \''+question.id+'\')">';
    
    order.forEach((item, index) => {
        html += `
            <div class="drag-item" draggable="true" 
                 data-index="${index}" 
                 ondragstart="handleDragStart(event, '${question.id}', ${index})"
                 ondragover="handleDragOver(event)"
                 ondrop="handleDrop(event, '${question.id}')">
                ${index + 1}. ${item}
            </div>
        `;
    });
    
    html += '</div></div>';
    return html;
}

let draggedElement = null;
let draggedIndex = null;
let draggedQuestionId = null;

function handleDragStart(e, questionId, index) {
    // Use currentTarget to ensure the draggable element is used even if the event target is a child
    draggedElement = e.currentTarget || e.target;
    draggedIndex = parseInt(index, 10);
    draggedQuestionId = questionId;
    // Some browsers require setting dataTransfer data for drag/drop to work
    try {
        e.dataTransfer.setData('text/plain', JSON.stringify({ questionId, index }));
        e.dataTransfer.effectAllowed = 'move';
    } catch (err) {
        // ignore if not supported
    }
    draggedElement.classList.add('dragging');
}

function handleDragOver(e) {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    // highlight drop area
    const list = e.currentTarget || e.target.closest('.drag-list');
    if (list && list.classList) list.classList.add('drag-over');
}

function handleDrop(e, questionId) {
    e.preventDefault();
    const listEl = e.target.closest('.drag-list');
    
    // Clear highlight
    if (listEl) listEl.classList.remove('drag-over');
    
    if (!draggedElement || draggedQuestionId !== questionId) {
        if (draggedElement) draggedElement.classList.remove('dragging');
        draggedElement = null;
        return;
    }
    
    const dropTarget = e.target.closest('.drag-item');
    const qObj = questions.find(q => q.id === questionId);

    if (!qObj || !listEl) {
        if (draggedElement) draggedElement.classList.remove('dragging');
        draggedElement = null;
        return;
    }

    // If dropping onto the same item, just cleanup
    if (dropTarget === draggedElement) {
        draggedElement.classList.remove('dragging');
        draggedElement = null;
        return;
    }

    // Build order from saved answers or default items
    const order = (userAnswers[questionId] || [...qObj.items]).slice();

    // Determine drop index: if dropped on an item use its index, otherwise append to end
    let dropIndex = dropTarget ? parseInt(dropTarget.dataset.index, 10) : order.length;

    // Move item from draggedIndex to dropIndex using splice (handles arbitrary moves)
    const movingItem = order.splice(draggedIndex, 1)[0];
    // Adjust dropIndex if the removal was before the target
    if (dropIndex > draggedIndex) dropIndex = dropIndex - 1;
    if (dropIndex >= order.length) {
        order.push(movingItem);
    } else {
        order.splice(dropIndex, 0, movingItem);
    }

    userAnswers[questionId] = order;
    saveAnswer(questionId, order);

    // Refresh display
    displayQuestion(currentQuestionIndex);

    if (draggedElement) draggedElement.classList.remove('dragging');
    draggedElement = null;
}

function createSimulationOptions(question) {
    const baseUrl = window.location.origin;
    let html = '<div class="simulation-info">';
    html += '<p><strong>Simulation Task:</strong> ' + question.question + '</p>';
    
    // Map endpoint keys to actual endpoints and create generic button text
    const endpointMap = {
        'a1b2c3': {
            url: `${baseUrl}/api/simulation/endpoint-a1b2c3?userId=1`,
            buttonText: 'Test Endpoint A (GET request)',
            instructions: 'Try changing the userId parameter (1, 2, 3, etc.) to test access control'
        },
        'd4e5f6': {
            url: `${baseUrl}/api/simulation/endpoint-d4e5f6?input=test`,
            buttonText: 'Test Endpoint D (GET request)',
            instructions: 'Try submitting different inputs including: <script>alert("test")</script>'
        },
        'g7h8i9': {
            url: `${baseUrl}/api/simulation/endpoint-g7h8i9`,
            buttonText: 'View Endpoint G Details',
            instructions: '',
            showTestButton: false,
            showMinimal: true
        }
    };
    
    const endpointKey = question.endpointKey || '';
    const endpointInfo = endpointMap[endpointKey];
    
    if (endpointInfo) {
        html += `<div style="margin: 15px 0; padding: 10px; background: rgba(255, 170, 0, 0.1); border: 1px solid rgba(255, 170, 0, 0.3); border-left: 4px solid var(--warning-color);">`;
        
        if (endpointInfo.showMinimal) {
            html += `<div style="margin-top: 10px; padding: 10px; background: rgba(13, 13, 13, 0.7); border: 1px solid rgba(0, 242, 234, 0.3);">
                <p style="margin-bottom: 5px;"><strong>Endpoint URL:</strong> <code style="color: var(--primary-color);">${endpointInfo.url}</code></p>
                <p style="margin-bottom: 0;"><strong>Method:</strong> POST</p>
            </div>`;
        } else if (endpointInfo.showTestButton !== false) {
            if (endpointInfo.instructions) {
                html += `<p style="margin-bottom: 8px;"><strong>Instructions:</strong> ${endpointInfo.instructions}</p>`;
            }
            html += `<a href="${endpointInfo.url}" 
                   target="_blank" 
                   class="simulation-link">${endpointInfo.buttonText}</a>`;
        } else {
            if (endpointInfo.instructions) {
                html += `<p style="margin-bottom: 8px;"><strong>Instructions:</strong> ${endpointInfo.instructions}</p>`;
            }
            html += `<div style="margin-top: 10px; padding: 10px; background: rgba(13, 13, 13, 0.7); border: 1px solid rgba(0, 242, 234, 0.3);">
                <p style="margin-bottom: 5px;"><strong>Endpoint URL:</strong> <code style="color: var(--primary-color);">${endpointInfo.url}</code></p>
                <p style="margin-bottom: 5px;"><strong>Method:</strong> POST</p>
                <p style="font-size: 12px; color: var(--text-color); margin-top: 10px;">
                    <strong>Quick Test:</strong> Open browser console (F12) and run:<br>
                    <code style="background: rgba(0, 0, 0, 0.5); padding: 5px; display: block; margin-top: 5px; color: var(--primary-color);">
                        fetch("${endpointInfo.url}", {method: "POST"}).then(r => r.json()).then(console.log)
                    </code>
                </p>
            </div>`;
        }
        
        html += `</div>`;
    } else {
        html += '<p style="color: var(--danger-color);">Simulation endpoint not configured for this question.</p>';
    }
    
    html += '</div>';
    html += '<div class="options-container">';
    question.options.forEach((option) => {
        const isChecked = userAnswers[question.id] === option ? 'checked' : '';
        html += `
            <label class="option-item ${isChecked ? 'selected' : ''}">
                <input type="radio" name="question-${question.id}" value="${option}" ${isChecked}
                       onchange="handleSingleChoice('${question.id}', '${option.replace(/'/g, "\\'")}')">
                ${option}
            </label>
        `;
    });
    html += '</div>';
    return html;
}

// Answer handlers
window.handleSingleChoice = function(questionId, answer) {
    userAnswers[questionId] = answer;
    saveAnswer(questionId, answer);
    updateQuestionNumbers();
    
    // Update UI
    document.querySelectorAll(`#question-${questionId} .option-item`).forEach(item => {
        item.classList.remove('selected');
    });
    event.target.closest('.option-item').classList.add('selected');
};

window.handleMultipleChoice = function(questionId, answer) {
    if (!userAnswers[questionId]) {
        userAnswers[questionId] = [];
    }
    
    const index = userAnswers[questionId].indexOf(answer);
    if (index > -1) {
        userAnswers[questionId].splice(index, 1);
    } else {
        userAnswers[questionId].push(answer);
    }
    
    saveAnswer(questionId, userAnswers[questionId]);
    updateQuestionNumbers();
    
    // Update UI
    event.target.closest('.option-item').classList.toggle('selected');
};

window.handleFillGap = function(questionId, index, value) {
    if (!userAnswers[questionId]) {
        userAnswers[questionId] = [];
    }
    userAnswers[questionId][index] = value;
    saveAnswer(questionId, userAnswers[questionId]);
    updateQuestionNumbers();
};

async function saveAnswer(questionId, answer) {
    try {
        await fetch('/api/save-answer', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ questionId, answer })
        });
    } catch (error) {
        console.error('Save answer error:', error);
    }
}

function navigateQuestion(direction) {
    const newIndex = currentQuestionIndex + direction;
    if (newIndex >= 0 && newIndex < questions.length) {
        displayQuestion(newIndex);
    }
}

function updateNavigation() {
    document.getElementById('prevBtn').disabled = currentQuestionIndex === 0;
    document.getElementById('nextBtn').style.display = 
        currentQuestionIndex === questions.length - 1 ? 'none' : 'inline-block';
    document.getElementById('submitBtn').style.display = 
        currentQuestionIndex === questions.length - 1 ? 'inline-block' : 'none';
}

function updateProgress() {
    const percentage = ((currentQuestionIndex + 1) / questions.length) * 100;
    document.getElementById('progressFill').style.width = percentage + '%';
    document.getElementById('currentQuestionNum').textContent = currentQuestionIndex + 1;
}

function setupNavigation() {
    // Click question numbers to navigate
}

function updateQuestionNumbers() {
    const container = document.getElementById('questionNumbers');
    container.innerHTML = '';
    
    questions.forEach((question, index) => {
        const num = document.createElement('div');
        num.className = 'question-number';
        num.textContent = index + 1;
        
        if (index === currentQuestionIndex) {
            num.classList.add('current');
        }
        
        if (userAnswers[question.id]) {
            num.classList.add('answered');
        }
        
        num.addEventListener('click', () => displayQuestion(index));
        container.appendChild(num);
    });
}

function showSubmitModal() {
    document.getElementById('submitModal').style.display = 'flex';
}

function hideSubmitModal() {
    document.getElementById('submitModal').style.display = 'none';
}

async function submitExam() {
    try {
        const response = await fetch('/api/submit-exam', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        });
        
        if (response.ok) {
            window.location.href = 'results.html';
        } else {
            alert('Failed to submit exam. Please try again.');
        }
    } catch (error) {
        console.error('Submit exam error:', error);
        alert('Network error. Please check your connection and try again.');
    }
}

