// Update score display on all pages
async function updateScore() {
  try {
    const response = await fetch('/api/scores');
    const data = await response.json();
    const scoreElements = document.querySelectorAll('#score');
    scoreElements.forEach(el => {
      el.textContent = data.totalScore;
    });
  } catch (error) {
    console.error('Error updating score:', error);
  }
}

// Run on page load
document.addEventListener('DOMContentLoaded', () => {
  updateScore();
  
  // Update score every 2 seconds
  setInterval(updateScore, 2000);
});

// Success notification
function showSuccessNotification(challengeName) {
  const notification = document.createElement('div');
  notification.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    background: linear-gradient(135deg, #9fef00 0%, #7bc700 100%);
    color: #0a0e27;
    padding: 20px 30px;
    border-radius: 8px;
    font-weight: bold;
    box-shadow: 0 8px 32px rgba(159, 239, 0, 0.4);
    z-index: 10000;
    animation: slideIn 0.5s ease;
  `;
  notification.innerHTML = `✓ ${challengeName} Completed! +250 pts`;
  document.body.appendChild(notification);
  
  setTimeout(() => {
    notification.style.animation = 'slideOut 0.5s ease';
    setTimeout(() => notification.remove(), 500);
  }, 3000);
}

// Add animations
const style = document.createElement('style');
style.textContent = `
  @keyframes slideIn {
    from {
      transform: translateX(400px);
      opacity: 0;
    }
    to {
      transform: translateX(0);
      opacity: 1;
    }
  }
  
  @keyframes slideOut {
    from {
      transform: translateX(0);
      opacity: 1;
    }
    to {
      transform: translateX(400px);
      opacity: 0;
    }
  }
`;
document.head.appendChild(style);
