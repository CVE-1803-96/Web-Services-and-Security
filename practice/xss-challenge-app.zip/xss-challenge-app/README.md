# K-Linker XSS Challenge Application

🎯 **Educational XSS Vulnerability Testing Platform**

A deliberately vulnerable web application designed for **K-Linker Club** at Djilali Liabes University to practice identifying and exploiting XSS vulnerabilities in a safe, controlled environment.

## ⚠️ DISCLAIMER

**THIS APPLICATION CONTAINS INTENTIONAL SECURITY VULNERABILITIES!**

- **DO NOT** deploy this application on a public server
- **DO NOT** use this code in production environments
- This is for **educational purposes only**
- Use only in isolated, local testing environments

## 🎨 Design

Inspired by **HackTheBox** and **PortSwigger** challenges:
- Dark theme with green (#9fef00) and yellow (#ffaf00) accents
- Black background gradient
- Modern, cybersecurity-themed UI

## 🚀 Quick Start

### Prerequisites
- Node.js (v14 or higher)
- npm

### Installation

```bash
# Navigate to project directory
cd xss-challenge-app

# Install dependencies
npm install

# Start the server
npm start
```

The application will be available at: **http://localhost:3000**

## 🎯 Challenges Overview

### Scoring System
- **10 Challenges** total
- **250 points** per challenge
- **2500 points** maximum score
- Track your progress on the `/scoreboard` page

## 📋 Challenge List

### Challenge 1: Reflected XSS - Search (250 pts) ⭐ EASY
**Location:** `/search`

**Description:** The search functionality reflects user input without sanitization.

**How to test:**
1. Navigate to Resources page
2. Search for items using the search bar
3. Notice how your search query appears in the results

**Hint:** Try injecting a `<script>` tag with `data-xss="challenge1"` attribute in the search parameter.

**Example payload:**
```
<script data-xss="challenge1">alert('XSS')</script>
```

---

### Challenge 2: Stored XSS - Comments (250 pts) ⭐ EASY
**Location:** `/comments`

**Description:** User comments are stored and displayed without sanitization.

**How to test:**
1. Navigate to Community page
2. Post a comment with malicious payload
3. The comment is stored and executed for all visitors

**Hint:** Include a `<script>` tag with `data-xss="challenge2"` in your comment.

**Example payload:**
```
<script data-xss="challenge2">alert('XSS')</script>
```

---

### Challenge 3: DOM XSS - Profile Update (250 pts) ⭐⭐ MEDIUM
**Location:** `/profile`

**Description:** Profile information from URL parameters is rendered using innerHTML without sanitization.

**How to test:**
1. Navigate to Profile page
2. Update your profile or modify URL parameters directly
3. The bio/username fields use DOM manipulation

**Hint:** The `username` or `bio` URL parameters are vulnerable. Use `data-xss="challenge3"` in your payload.

**Example URL:**
```
http://localhost:3000/profile?username=<script data-xss="challenge3">fetch('/api/complete/challenge3',{method:'POST'})</script>
```

---

### Challenge 4: Reflected XSS - Error Message (250 pts) ⭐ EASY
**Location:** `/login`

**Description:** Error messages reflect user input without proper encoding.

**How to test:**
1. Navigate to Login page or access with error parameter
2. The error parameter is reflected in the page

**Hint:** Use the `error` query parameter with `data-xss="challenge4"`.

**Example URL:**
```
http://localhost:3000/login?error=<script data-xss="challenge4">alert('XSS')</script>
```

---

### Challenge 5: Stored XSS - Chat Room (250 pts) ⭐⭐ MEDIUM
**Location:** `/chat`

**Description:** Chat messages are stored and displayed without sanitization.

**How to test:**
1. Navigate to Chat Room
2. Send a message with malicious payload
3. Messages persist and execute for all users

**Hint:** Chat messages support HTML. Include `data-xss="challenge5"`.

**Example message:**
```
<script data-xss="challenge5">alert('XSS')</script>
```

---

### Challenge 6: DOM XSS - URL Fragment (250 pts) ⭐⭐ MEDIUM
**Location:** `/welcome`

**Description:** The page reads from URL fragment (hash) and renders it without sanitization.

**How to test:**
1. Navigate to Welcome page
2. Add a name after the # in URL
3. The fragment is processed client-side

**Hint:** Use the URL hash with `data-xss="challenge6"`.

**Example URL:**
```
http://localhost:3000/welcome#<script data-xss="challenge6">fetch('/api/complete/challenge6',{method:'POST'})</script>
```

---

### Challenge 7: Reflected XSS - Event Filter (250 pts) ⭐⭐ MEDIUM
**Location:** `/events`

**Description:** Event filtering reflects user input in the filter display.

**How to test:**
1. Navigate to Events page
2. Use the filter functionality
3. Filter values are reflected in the page

**Hint:** The `filter` parameter is vulnerable. Use `data-xss="challenge7"`.

**Example URL:**
```
http://localhost:3000/events?filter=<script data-xss="challenge7">alert('XSS')</script>
```

---

### Challenge 8: Stored XSS - Event Description (250 pts) ⭐⭐⭐ HARD
**Location:** `/event/:id`

**Description:** Event descriptions can be updated and are stored without sanitization.

**How to test:**
1. Navigate to any event detail page (e.g., `/event/1`)
2. Use the "Update Event Description" form
3. Descriptions are stored and rendered

**Hint:** Update the description with `data-xss="challenge8"`.

**Example payload:**
```
<script data-xss="challenge8">alert('XSS')</script>
```

---

### Challenge 9: DOM XSS - JavaScript Protocol (250 pts) ⭐⭐⭐ HARD
**Location:** `/resources`

**Description:** User-controlled URLs are used to create links, allowing javascript: protocol execution.

**How to test:**
1. Navigate to Resource Library page
2. Enter a URL in the quick link form
3. The URL becomes an href attribute

**Hint:** Use `javascript:` protocol. Include `data-xss="challenge9"` attribute in your payload.

**Example payload:**
```
javascript:void(document.body.innerHTML='<script data-xss="challenge9">fetch("/api/complete/challenge9",{method:"POST"})</script>')
```

---

### Challenge 10: Advanced Reflected XSS - WAF Bypass (250 pts) ⭐⭐⭐⭐ EXPERT
**Location:** `/feedback`

**Description:** Basic WAF filters block common XSS patterns, but can be bypassed.

**How to test:**
1. Navigate to Feedback page
2. Notice the WAF blocks: `<script`, `javascript:`, `onerror`, `onload`
3. Find alternative XSS vectors that bypass the filter

**Hint:** Use HTML tags other than `<script>`. SVG, IMG with event handlers, or other creative bypasses work. Include `data-xss="challenge10"` attribute.

**Example payloads:**
```html
<a href="jav&#x61;script:fetch('/api/complete/challenge10',{method:'POST'})">Click</a>
```

**Note:** Case manipulation or encoding might bypass the simple regex filter.

---

## 🔧 Technical Details

### Application Structure
```
xss-challenge-app/
├── database/           # JSON files for data storage
│   ├── scores.json     # Challenge completion tracking
│   ├── comments.json   # Community comments
│   ├── chat.json       # Chat messages
│   ├── events.json     # Event listings
│   └── resources.json  # Resource items
├── public/             # Static files
│   ├── style.css       # HackTheBox-inspired styling
│   └── script.js       # Client-side score tracking
├── views/              # HTML pages
│   ├── index.html      # Home page
│   ├── profile.html    # Profile (Challenge 3)
│   ├── welcome.html    # Welcome (Challenge 6)
│   └── resources.html  # Resources (Challenge 9)
├── server.js           # Express server with vulnerabilities
├── package.json        # Dependencies
└── README.md           # This file
```

### Technologies Used
- **Backend:** Node.js, Express.js
- **Data Storage:** JSON files (no database required)
- **Frontend:** Vanilla JavaScript, CSS3, HTML5

### Key Features
- Real-time score tracking
- Automatic challenge detection
- Progress persistence
- Reset functionality
- Responsive design

## 🎓 Learning Objectives

By completing these challenges, you will learn about:

1. **Reflected XSS** - Understanding how user input is reflected in responses
2. **Stored XSS** - Persistent attacks that affect multiple users
3. **DOM-based XSS** - Client-side vulnerabilities in JavaScript
4. **Context-specific XSS** - Different injection points require different payloads
5. **WAF Bypasses** - Techniques to evade basic security filters
6. **XSS Prevention** - Understanding what NOT to do in production code

## 🛡️ Security Best Practices (What NOT to do)

This application demonstrates several anti-patterns:

❌ **Never** output user input without sanitization
❌ **Never** use `innerHTML` with untrusted data
❌ **Never** trust URL parameters, fragments, or query strings
❌ **Never** create links with user-controlled URLs
❌ **Never** rely solely on client-side filtering
❌ **Never** use simple regex patterns as security controls

✅ **Instead, use:**
- Content Security Policy (CSP)
- Output encoding/escaping
- Input validation and sanitization
- `textContent` instead of `innerHTML`
- Secure templating engines
- Proper Content-Type headers

## 📊 Progress Tracking

Visit `/scoreboard` to see:
- Total score (out of 2500 points)
- Progress bar visualization
- List of all challenges
- Completion status for each challenge
- Reset option to start over

## 🤝 Contributing

This is an educational project for K-Linker Club members. Suggestions for improvements or additional challenges are welcome!

## 👥 About K-Linker Club

K-Linker is the premier technology and cybersecurity club at **Djilali Liabes University**. We focus on:
- Ethical hacking and penetration testing
- Programming workshops
- CTF competitions
- Networking events
- Skill development

## 👥 About Bedratkhayr Club

K-Linker is the premier technology and cybersecurity club at **Djilali Liabes University**. We focus on:
- Ethical hacking and penetration testing
- Programming workshops
- CTF competitions
- Networking events
- Skill development

## 📝 License

MIT License - Educational use only

## 🎉 Happy Hacking!

Remember: These are **intentional vulnerabilities** for learning purposes. Always practice ethical hacking and never test security on systems you don't own or have explicit permission to test.

---

**Good luck with the challenges! 🚀**

For questions or support, contact K-Linker Club administrators.
